package enviromine.blocks.tiles;

import net.minecraft.tileentity.TileEntity;

public class TileEntityElevator extends TileEntity
{
}
