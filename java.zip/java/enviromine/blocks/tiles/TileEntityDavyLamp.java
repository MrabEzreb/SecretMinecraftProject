package enviromine.blocks.tiles;

import net.minecraft.tileentity.TileEntity;

public class TileEntityDavyLamp extends TileEntity
{
	public TileEntityDavyLamp()
	{
	}
}
